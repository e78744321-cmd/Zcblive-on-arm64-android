# ZCB Live — Android ARM64 porting package

This archive adds an Android64 build workflow, Android GD metadata, and an Android
Rust static-library path to the CMake project.

## Important: this is not yet a working Android port

The supplied source is currently Windows-specific in several essential places:

- `src/main.cpp` uses Windows types (`HDC`) and the WGL `swapBuffers` hook.
- `live/egui_gl_hook` uses Win32 window messages, WGL, and the Windows clipboard.
- `live/Cargo.toml` and `live/egui_gl_hook/Cargo.toml` include Windows-only crates/APIs.
- The Rust bot UI currently depends on the Windows-oriented `egui_gl_hook`.

Therefore the Android workflow is a porting/build diagnostic, not a guaranteed
successful build. A real Android ARM64 port must replace the WGL/Win32 overlay
with Android-compatible EGL/OpenGL ES and touch/input integration, then adapt
the platform-specific Rust dependencies and C++ hooks. Do not install a build
artifact unless the workflow produces a valid `.geode` file and it is tested
with the matching Geometry Dash and Geode versions.
