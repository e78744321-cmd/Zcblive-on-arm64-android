#pragma once
#if defined(__ANDROID__)
#include <Geode/Geode.hpp>
#include <algorithm>

namespace zcb {
using namespace geode::prelude;

extern "C" bool zcblive_android_get_bot_enabled();
extern "C" bool zcblive_android_toggle_bot();
extern "C" bool zcblive_android_get_noise_enabled();
extern "C" bool zcblive_android_toggle_noise();

class FloatingOverlay final : public CCLayer {
    CCLayerColor* m_bubble = nullptr;
    CCLayerColor* m_panel = nullptr;
    CCLabelBMFont* m_botLabel = nullptr;
    CCLabelBMFont* m_noiseLabel = nullptr;
    CCPoint m_touchStart{};
    CCPoint m_bubbleStart{};
    bool m_dragging = false;
    bool m_moved = false;
    bool m_touchOnPanel = false;

    void refreshLabels() {
        if (m_botLabel)
            m_botLabel->setString(zcblive_android_get_bot_enabled() ? "BOT: ON" : "BOT: OFF");
        if (m_noiseLabel)
            m_noiseLabel->setString(zcblive_android_get_noise_enabled() ? "SOUND: ON" : "SOUND: OFF");
    }

    bool inNode(CCNode* node, CCPoint world) {
        return node && node->isVisible() && node->boundingBox().containsPoint(convertToNodeSpace(world));
    }

    void togglePanel() {
        if (m_panel) m_panel->setVisible(!m_panel->isVisible());
    }

public:
    static FloatingOverlay* create() {
        auto ret = new FloatingOverlay();
        if (ret && ret->init()) { ret->autorelease(); return ret; }
        CC_SAFE_DELETE(ret);
        return nullptr;
    }

    bool init() override {
        if (!CCLayer::init()) return false;
        setTouchEnabled(true);
        setTouchMode(kCCTouchesOneByOne);
        setTouchPriority(-500);

        auto size = CCDirector::sharedDirector()->getWinSize();
        m_bubble = CCLayerColor::create({35, 170, 110, 235}, 46.f, 46.f);
        m_bubble->setPosition({size.width - 62.f, size.height * 0.55f - 23.f});
        auto bubbleText = CCLabelBMFont::create("Z", "bigFont.fnt");
        bubbleText->setScale(0.75f);
        bubbleText->setPosition({23.f, 23.f});
        m_bubble->addChild(bubbleText);
        addChild(m_bubble, 10);

        m_panel = CCLayerColor::create({18, 22, 32, 225}, 190.f, 112.f);
        m_panel->setAnchorPoint({0.f, 0.f});
        auto title = CCLabelBMFont::create("ZCB LIVE", "bigFont.fnt");
        title->setScale(0.42f);
        title->setAnchorPoint({0.f, 0.5f});
        title->setPosition({10.f, 94.f});
        m_panel->addChild(title);

        m_botLabel = CCLabelBMFont::create("", "bigFont.fnt");
        m_botLabel->setScale(0.38f);
        m_botLabel->setAnchorPoint({0.f, 0.5f});
        m_botLabel->setPosition({12.f, 64.f});
        m_panel->addChild(m_botLabel);

        m_noiseLabel = CCLabelBMFont::create("", "bigFont.fnt");
        m_noiseLabel->setScale(0.38f);
        m_noiseLabel->setAnchorPoint({0.f, 0.5f});
        m_noiseLabel->setPosition({12.f, 34.f});
        m_panel->addChild(m_noiseLabel);

        auto close = CCLabelBMFont::create("X", "bigFont.fnt");
        close->setScale(0.5f);
        close->setPosition({174.f, 94.f});
        m_panel->addChild(close);

        m_panel->setPosition({size.width - 205.f, size.height * 0.55f - 56.f});
        addChild(m_panel, 9);
        m_panel->setVisible(false);
        refreshLabels();
        return true;
    }

    void ccTouchMoved(CCTouch* touch, CCEvent*) override {
        if (!m_dragging) return;
        auto now = touch->getLocation();
        auto delta = ccpSub(now, m_touchStart);
        if (ccpLength(delta) > 5.f) m_moved = true;
        if (m_moved) {
            auto size = CCDirector::sharedDirector()->getWinSize();
            auto pos = ccpAdd(m_bubbleStart, delta);
            pos.x = std::max(22.f, std::min(size.width - 22.f, pos.x));
            pos.y = std::max(22.f, std::min(size.height - 22.f, pos.y));
            m_bubble->setPosition(pos);
        }
    }

    bool ccTouchBegan(CCTouch* touch, CCEvent*) override {
        auto point = touch->getLocation();
        m_touchOnPanel = m_panel && m_panel->isVisible() && inNode(m_panel, point);
        if (m_touchOnPanel) return true;
        if (!m_bubble || !inNode(m_bubble, point)) return false;
        m_dragging = true;
        m_moved = false;
        m_touchStart = point;
        m_bubbleStart = m_bubble->getPosition();
        return true;
    }

    void ccTouchEnded(CCTouch* touch, CCEvent*) override {
        auto local = convertToNodeSpace(touch->getLocation());
        if (m_touchOnPanel) {
            m_touchOnPanel = false;
            auto panelPos = m_panel->getPosition();
            auto x = local.x - panelPos.x;
            auto y = local.y - panelPos.y;
            if (y > 48.f && y < 82.f && x < 145.f) onBot(nullptr);
            else if (y > 18.f && y < 48.f && x < 145.f) onNoise(nullptr);
            else if (y > 78.f && x > 150.f) m_panel->setVisible(false);
            return;
        }
        if (!m_dragging) return;
        m_dragging = false;
        if (!m_moved) togglePanel();
    }

    void onBot(CCObject*) { zcblive_android_toggle_bot(); refreshLabels(); }
    void onNoise(CCObject*) { zcblive_android_toggle_noise(); refreshLabels(); }
};

inline void installOverlay(CCScene* scene) {
    if (!scene || scene->getChildByID("zcb-live-android-overlay")) return;
    auto overlay = FloatingOverlay::create();
    if (overlay) {
        overlay->setID("zcb-live-android-overlay");
        scene->addChild(overlay, 9999);
    }
}
} // namespace zcb
#endif
